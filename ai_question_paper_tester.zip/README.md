# AI Question Paper Tester — first prototype

This prototype is built around the uploaded scanned NIT Durgapur Computer Programming PDF.

## What it does
1. Upload the scanned PDF.
2. OCRs each page with Tesseract when normal PDF text is missing.
3. Detects paper sections such as End-Term / Mid-Term / Backlog.
4. Lets you select a detected paper and question.
5. Sends the selected question + the OCR context for that paper to both OpenAI and Gemini.
6. Shows both answers side-by-side.

The OCR is deliberately preserved rather than silently correcting the PDF. Scanned question papers can contain OCR errors, so this is a testing prototype; the next version should use page images + multimodal models for ambiguous questions.

## Run on Windows
Install Python 3.11+ and Tesseract OCR.

Install Tesseract:
https://github.com/tesseract-ocr/tesseract

Then:
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Put your API keys in `.env` or set them in the terminal:
```bash
set OPENAI_API_KEY=...
set GEMINI_API_KEY=...
```

Start:
```bash
python app.py
```

Open:
http://127.0.0.1:5000

## Run on Linux/macOS
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
export OPENAI_API_KEY="..."
export GEMINI_API_KEY="..."
python app.py
```

## Important
Do not put API keys in the browser JavaScript. The keys belong on the server.

OpenAI's current API supports Responses API text generation and file inputs; Gemini's current API supports PDF inputs and `generate_content`. The implementation here uses OCR text for the first test so the app can work with the scanned PDF while we refine extraction.
