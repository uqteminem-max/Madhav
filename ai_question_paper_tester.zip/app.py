
import os, re, uuid, json
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_from_directory
import fitz
import pytesseract
from PIL import Image
from openai import OpenAI
from google import genai

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / "uploads"
UPLOADS.mkdir(exist_ok=True)
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 60 * 1024 * 1024

OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")

def ocr_pdf(path):
    doc = fitz.open(path)
    pages = []
    for i, page in enumerate(doc):
        text = page.get_text("text").strip()
        if len(text) < 40:
            pix = page.get_pixmap(matrix=fitz.Matrix(1.6, 1.6), alpha=False)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            text = pytesseract.image_to_string(img)
        pages.append({"page": i + 1, "text": text})
    return pages

def detect_papers(pages):
    # Header-oriented grouping. The original PDF is scanned, so OCR can be imperfect.
    groups = []
    current = None
    for p in pages:
        t = p["text"]
        m = re.search(r"(End[- ]Term|End[- ]Sem|Mid[- ]Term|Backlog).*?Examination.*?20\d\d", t, re.I|re.S)
        if m:
            title = re.sub(r"\s+", " ", m.group(0)).strip()
            code = re.search(r"Course Code:\s*([A-Z0-9]+)", t, re.I)
            course = re.search(r"Course Name:\s*(.+)", t, re.I)
            current = {
                "id": str(uuid.uuid4()),
                "title": title[:140],
                "course_code": code.group(1) if code else "",
                "course_name": course.group(1).splitlines()[0][:100] if course else "",
                "start_page": p["page"],
                "pages": []
            }
            groups.append(current)
        if current is None:
            current = {
                "id": str(uuid.uuid4()), "title": "Unidentified paper",
                "course_code": "", "course_name": "", "start_page": p["page"], "pages": []
            }
            groups.append(current)
        current["pages"].append(p["page"])
    for g in groups:
        g["end_page"] = g["pages"][-1]
    return groups

def extract_questions(text):
    # Conservative parser: preserve OCR text rather than inventing missing characters.
    pat = re.compile(r"(?m)^\s*(?:Question\s*)?(\d{1,2})\s*[\.\):\-]\s+")
    matches = list(pat.finditer(text))
    out = []
    for idx, m in enumerate(matches):
        num = m.group(1)
        start = m.end()
        end = matches[idx+1].start() if idx+1 < len(matches) else len(text)
        body = text[start:end].strip()
        if len(body) >= 15:
            out.append({"number": num, "text": re.sub(r"\n{3,}", "\n\n", body)})
    return out

def get_paper_payload(paper, pages):
    selected = [p for p in pages if paper["start_page"] <= p["page"] <= paper["end_page"]]
    full = "\n\n".join(f"[PDF page {p['page']}]\n{p['text']}" for p in selected)
    return selected, full

def openai_answer(question, paper_text):
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        return {"ok": False, "error": "OPENAI_API_KEY is not configured."}
    client = OpenAI(api_key=key)
    prompt = f"""You are solving a university Computer Programming (C) question.
Use the supplied OCR from the uploaded question paper as the source for the exact wording.
Do not silently change the question. If OCR is ambiguous, explicitly say what is unclear.
Give a correct, exam-ready answer with reasoning where appropriate.

QUESTION:
{question}

QUESTION-PAPER OCR CONTEXT:
{paper_text[:50000]}
"""
    r = client.responses.create(model=OPENAI_MODEL, input=prompt, store=False)
    return {"ok": True, "answer": r.output_text}

def gemini_answer(question, paper_text):
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        return {"ok": False, "error": "GEMINI_API_KEY is not configured."}
    client = genai.Client(api_key=key)
    prompt = f"""Solve this university Computer Programming (C) question.
Use the question-paper OCR below as the source for wording. Do not invent missing parts.
If OCR is ambiguous, identify the ambiguity. Give an exam-ready answer and reasoning.

QUESTION:
{question}

QUESTION-PAPER OCR CONTEXT:
{paper_text[:50000]}
"""
    r = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
    return {"ok": True, "answer": r.text}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/process", methods=["POST"])
def process():
    f = request.files.get("pdf")
    if not f:
        return jsonify({"error": "Upload a PDF."}), 400
    path = UPLOADS / (uuid.uuid4().hex + ".pdf")
    f.save(path)
    pages = ocr_pdf(path)
    papers = detect_papers(pages)
    payload = {"file": f.filename, "pages": pages, "papers": papers}
    json_path = DATA / (path.stem + ".json")
    json_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    return jsonify({"id": path.stem, "file": f.filename, "papers": papers})

@app.route("/api/paper/<pid>")
def paper(pid):
    p = DATA / f"{pid}.json"
    if not p.exists():
        return jsonify({"error": "Processed PDF not found."}), 404
    payload = json.loads(p.read_text(encoding="utf-8"))
    return jsonify(payload)

@app.route("/api/answer", methods=["POST"])
def answer():
    data = request.get_json(force=True)
    pid = data.get("id")
    paper_id = data.get("paper_id")
    question = data.get("question", "").strip()
    provider = data.get("provider", "both")
    if not pid or not question:
        return jsonify({"error": "Missing id or question."}), 400
    payload = json.loads((DATA / f"{pid}.json").read_text(encoding="utf-8"))
    paper = next((x for x in payload["papers"] if x["id"] == paper_id), None)
    if not paper:
        return jsonify({"error": "Paper not found."}), 404
    _, context = get_paper_payload(paper, payload["pages"])
    result = {}
    if provider in ("openai", "both"):
        result["chatgpt"] = openai_answer(question, context)
    if provider in ("gemini", "both"):
        result["gemini"] = gemini_answer(question, context)
    return jsonify(result)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=True)
